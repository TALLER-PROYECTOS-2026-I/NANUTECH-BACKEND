# Auth Contract

Contrato minimo del modulo `auth-services` para frontend, QA y DevSecOps.

## Provider actual

- `AUTH_PROVIDER=local`: fallback provisional para desarrollo y pruebas.
- `AUTH_PROVIDER=cognito`: usa Cognito real si tambien existen `COGNITO_USER_POOL_ID` y `COGNITO_CLIENT_ID`.

## Variables relacionadas a auth y Cognito

- `AUTH_PROVIDER`
- `COGNITO_USER_POOL_ID`
- `COGNITO_CLIENT_ID`
- `AWS_REGION` o `AWS_DEFAULT_REGION`
- `SESSION_TIMEOUT_SECONDS`
- `AUTH_TOKEN_SECRET`

## Estado actual del backend

- Hoy el backend puede operar completo en modo `local` para no bloquear desarrollo, frontend y QA.
- El modo `cognito` ya esta preparado en codigo, pero depende de infraestructura real y configuracion de entorno.
- El fallback local sigue siendo provisional y no debe considerarse autenticacion final de produccion.
- Para cerrar auth real en nube todavia se necesita un User Pool activo, App Client valido, variables por ambiente y pruebas con usuarios reales.

## Endpoints

### `POST /auth/login`

- Tipo: publico

Body:

```json
{
  "email": "test@test.com",
  "password": "123456"
}
```

Respuesta exitosa:

```json
{
  "success": true,
  "message": "Resultado de login",
  "data": {
    "user": {
      "email": "test@test.com",
      "role": "admin"
    },
    "session": {
      "provider": "local",
      "accessToken": "token",
      "tokenType": "Bearer",
      "expiresIn": 7200,
      "expiresAt": "2026-04-01T15:00:00.000Z",
      "idleTimeoutSeconds": 7200
    },
    "nextRoute": "/dashboard/admin"
  }
}
```

Errores principales:

- `400`: email o password invalidos
- `401`: credenciales invalidas
- `403`: usuario no confirmado en Cognito
- `404`: usuario no encontrado
- `423`: cuenta bloqueada
- `502`: error de integracion con Cognito

### `POST /auth/forgot-password`

- Tipo: publico

Body:

```json
{
  "email": "test@test.com"
}
```

Respuesta exitosa:

```json
{
  "success": true,
  "message": "Correo de recuperacion enviado",
  "data": {
    "email": "test@test.com",
    "provider": "local",
    "message": "Se envio un enlace de recuperacion (simulado)"
  }
}
```

Notas:

- En modo `local` el codigo de prueba para confirmar recuperacion es `123456`.
- En modo `cognito` el backend delega el inicio del flujo a Cognito.

Errores principales:

- `400`: email invalido
- `502`: error de integracion con Cognito

### `POST /auth/forgot-password/confirm`

- Tipo: publico

Body:

```json
{
  "email": "test@test.com",
  "code": "123456",
  "newPassword": "NuevaClave123"
}
```

Respuesta exitosa:

```json
{
  "success": true,
  "message": "Contrasena actualizada",
  "data": {
    "email": "test@test.com",
    "provider": "local",
    "message": "La contrasena fue actualizada"
  }
}
```

Errores principales:

- `400`: payload invalido o nueva contrasena invalida
- `401`: codigo invalido o expirado
- `404`: usuario no encontrado
- `502`: error de integracion con Cognito

### `GET /auth/me`

- Tipo: protegido

Headers:

```text
Authorization: Bearer <accessToken>
```

Respuesta exitosa:

```json
{
  "success": true,
  "message": "Sesion valida",
  "data": {
    "user": {
      "email": "test@test.com",
      "role": "admin"
    },
    "session": {
      "provider": "local",
      "tokenType": "Bearer",
      "expiresAt": "2026-04-01T15:00:00.000Z",
      "idleTimeoutSeconds": 7200,
      "isAuthenticated": true
    },
    "nextRoute": "/dashboard/admin"
  }
}
```

Errores principales:

- `401`: token faltante, invalido o expirado
- `502`: error de validacion con Cognito

## Role y nextRoute

- El rol se obtiene con esta prioridad en modo `cognito`:
  1. `cognito:groups`
  2. `custom:role`
  3. `role`
- `role` y `nextRoute` se devuelven para que el cliente decida la redireccion.
- Si Cognito no expone ninguna de esas fuentes, el backend conserva el comportamiento actual y devuelve `role: null`.

## Dependencias con DevSecOps

- User Pool activo
- App Client valido
- Variables de entorno por ambiente
- Roles disponibles en claims, atributos o grupos de Cognito
- Exposicion real del modulo auth en la infraestructura cloud
